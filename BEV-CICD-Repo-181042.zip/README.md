# BEV Backend — Deploy Repo

Push a build here and it deploys to Azure automatically. No PowerShell.

- `hive/`    — Hive Function App source. Edit + push -> deploys to bev-hive-fn.
               Set the build label in `hive/BUILD_LABEL.txt`.
- `server/`  — Server Function App source. Push -> deploys to bev-server-fn.
- `.github/workflows/` — the pipelines (do not need editing).

FIRST TIME: do `SETUP_ONE_TIME.md` once. After that, deploys are automatic.

Manual deploy without pushing: Actions tab -> pick the workflow -> Run workflow.
